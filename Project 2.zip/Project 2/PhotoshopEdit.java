import java.util.Scanner;

public class PhotoshopEdit {
    public Stack history;

    /**
     * constructor that creates empty
     * stack to store edit history
     */
    public PhotoshopEdit() {
        history = new Stack();
    }
}

